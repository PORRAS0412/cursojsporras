// .toUpperCase() te va a permitir cambiar un texto a todo mayusculas
const producto = 'Monitor 24 pulgadas ';
console.log(producto.toUpperCase() );

// .toLowerCase()
console.log(producto.toLowerCase() );

// .toString()
const cantidad = 200;
console.log(cantidad);
console.log(cantidad.toString());

