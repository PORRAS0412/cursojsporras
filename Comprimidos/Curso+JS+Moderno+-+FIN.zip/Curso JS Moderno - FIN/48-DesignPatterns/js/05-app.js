// Organizar código

// Module, Probablemente el más popular de todos, ya lo hemos utilizado...

// Su Sintaxis era un poco diferente antes, ahora ya tenemos modules en JavaScript por lo tanto ya se siente como una solución más natural, ya que antes parecia algo muy sacado de la manga...


const mostrarCliente = nombre => {
    console.log(nombre);
}

export default mostrarCliente


var module1 = (function() {

})();