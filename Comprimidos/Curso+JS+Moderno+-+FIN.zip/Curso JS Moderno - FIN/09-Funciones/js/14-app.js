// Object constructor...

function Producto() {
    
}