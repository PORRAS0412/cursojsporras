import App from './classes/App';

App();
